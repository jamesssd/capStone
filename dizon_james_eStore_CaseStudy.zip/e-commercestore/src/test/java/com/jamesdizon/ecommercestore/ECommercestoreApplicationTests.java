package com.jamesdizon.ecommercestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommercestoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
