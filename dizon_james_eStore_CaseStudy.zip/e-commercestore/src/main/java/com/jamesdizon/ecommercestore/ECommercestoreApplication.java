package com.jamesdizon.ecommercestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommercestoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommercestoreApplication.class, args);
	}

}
