package com.jamesdizon.ecommercestore.exception;

public class UserCheck extends Exception {

}
